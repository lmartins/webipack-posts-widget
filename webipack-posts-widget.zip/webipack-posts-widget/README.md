# webipack-posts-widget
Customised version of Flexible Posts Widget with extra options
